// Write an Array#merge_sort method; it should not modify the original array.

Array.prototype.mergeSort = function (func) {

}

Array.prototype.merge = function (arr, func) {

}
