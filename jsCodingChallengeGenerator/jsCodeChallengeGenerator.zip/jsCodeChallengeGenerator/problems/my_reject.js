Array.prototype.reject = function (func) {

}
