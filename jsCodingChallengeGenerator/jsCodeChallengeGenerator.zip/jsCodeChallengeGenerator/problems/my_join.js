Array.prototype.myJoin = function (separator) {

}
