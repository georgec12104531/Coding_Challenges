Array.prototype.myFilter = function (func) {

}
