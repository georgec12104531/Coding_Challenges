// write Function.prototype.inherits.

Function.prototype.inherits = function () {
  
}
