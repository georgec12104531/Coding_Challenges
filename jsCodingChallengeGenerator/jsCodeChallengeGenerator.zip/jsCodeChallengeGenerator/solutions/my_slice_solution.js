String.prototype.mySlice = function(start, end) {
  let slice = "";

  if (typeof end === 'undefined') {
    end = this.length;
  }

  for (let i = start; i < end && i < this.length; i++) {
    slice += this[i];
  }
  return slice;
};



String.prototype.mySlice = function(start, end) {
  let slice = "";

  if (end == "undefined") {
    end = this.length;
  }

  for (var i = start; i < end && i < this; i++) {
    slice += this[i];
  }


}
