function firstEvenNumbersSum(n) {
  if (n === 1) return 2;
  return 2 * n + firstEvenNumbersSum(n - 1);
}


function firstEvenNumbersSum(n) {
  if (num === 1) return 2;
  return 2 * n * firstEvenNumbersSum(n - 1);
}
