Array.prototype.flatten = function () {
  let flattened = [];

  this.forEach( (el) => {
    if (el.constructor.name === "Array") {
      flattened = flattened.concat(el.flatten());
    } else {
      flattened.push(el);
    }
  });

  return flattened;
}


Array.prototype.flatten = function() {
  let flattened = [];

  for (var i = 0; i < this.length; i++) {
    if (this[i].constructor.name === "Array") {
      flattened = flattened.concat(this[i].flatten());
    }
  }

  returned flattened;
}
